<template>
    <head>
        <title>Frequently asked and questions</title>
    </head>
    <div><h3 class="text-xl text-center">Faq</h3></div>
</template>
<script>
import HomeLayout from './layouts/HomeLayout.vue';

export default{
    layout: HomeLayout
}
</script>
