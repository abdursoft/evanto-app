<template>
    <img src="../../../images/rstream.png" class="w-[110px] h-[40px] rounded-md" alt="">
</template>
