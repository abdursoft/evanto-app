<template>
    <div class="bg-white w-full py-[50px]">
        <div class="w-full max-w-[1060px] m-auto flex flex-col my-[40px] items-center px-3 md:px-0 gap-3"
            data-aos="fade-up">
            <h4 class="bg-slate-200 py-2 px-4 rounded-lg max-w-[140px] text-blue-800 font-bold">Payments</h4>
            <h1 class="font-base md:font-[700] text-center text-slate-600 mt-3 text-[28px] md:text-[45px] ls-0">Multiple
                payment gateways</h1>
            <h4 class="text-justify md:text-center text-slate-500 text-md md:text-lg md:font-semibold mt-2">We have
                added 8 payment gateways to collect the subscription payments.</h4>

            <div class="w-full flex items-center flex-col md:flex-row flex-wrap">
                <div class="my-5 w-full flex items-center flex-row justify-center flex-wrap">
                    <div class="w-1/2 md:w-1/3 md:p-3 my-4 flex items-center justify-center">
                        <img src="../../../images/paypal.png" data-aos="zoom-in" class="w-[140px] h-[120px]" alt="">
                    </div>
                    <div class="w-1/2 md:w-1/3 md:p-3 my-4 flex items-center justify-center">
                        <img src="../../../images/stripe.png" data-aos="zoom-in" class="w-[140px] h-[120px]" alt="">
                    </div>
                    <div class="w-1/2 md:w-1/3 md:p-3 my-4 flex items-center justify-center">
                        <img src="../../../images/ssl.png" data-aos="zoom-in" class="w-[140px] h-[120px]" alt="">
                    </div>
                    <div class="w-1/2 md:w-1/3 md:p-3 my-4 flex items-center justify-center">
                        <img src="../../../images/bkash.png" data-aos="zoom-in" class="w-[140px] h-[120px]" alt="">
                    </div>
                    <div class="w-1/2 md:w-1/3 md:p-3 my-4 flex items-center justify-center">
                        <img src="../../../images/flutter.png" data-aos="zoom-in" class="w-[140px] h-[120px]" alt="">
                    </div>
                    <div class="w-1/2 md:w-1/3 md:p-3 my-4 flex items-center justify-center">
                        <img src="../../../images/checkout.png" data-aos="zoom-in" class="w-[140px] h-[120px]" alt="">
                    </div>
                    <div class="w-1/2 md:w-1/3 md:p-3 my-4 flex items-center justify-center">
                        <img src="../../../images/instamojo.png" data-aos="zoom-in" class="w-[140px] h-[120px]" alt="">
                    </div>
                    <div class="w-1/2 md:w-1/3 md:p-3 my-4 flex items-center justify-center">
                        <img src="../../../images/razorpay.png" data-aos="zoom-in" class="w-[140px] h-[120px]" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
