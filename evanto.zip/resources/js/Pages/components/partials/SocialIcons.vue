<template>
    <div class="flex w-full items-center justify-center md:justify-end gap-3 my-2">
        <Icon icon="mingcute:facebook-line" width="34" height="34" class="cursor-pointer text-slate-500 hover:text-blue-500" />
        <Icon icon="simple-icons:instagram" width="24" height="24" class="cursor-pointer text-slate-500 hover:text-blue-500" />
        <Icon icon="proicons:x-twitter" width="24" height="24" class="cursor-pointer text-slate-500 hover:text-blue-500" />
        <Icon icon="mynaui:brand-youtube" width="34" height="34" class="cursor-pointer text-slate-500 hover:text-blue-500" />
    </div>
</template>

<script setup>
import { Icon } from '@iconify/vue';
</script>
