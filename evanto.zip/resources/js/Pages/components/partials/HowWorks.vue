<template>
    <div class="w-full max-w-[1060px] m-auto flex items-center flex-col my-12 px-3 md:px-0" data-aos="fade-up">
        <h4 class="bg-slate-200 py-2 px-4 rounded-lg max-w-[140px] text-blue-800 font-bold">OTT platform</h4>
        <h1 class="font-base md:font-[700] text-center text-slate-600 mt-3 text-[28px] md:text-[45px] ls-0">Easily lunch your video OTT platform, Today</h1>
        <h4 class="text-justify md:text-center text-slate-500 text-base md:text-lg md:font-semibold mt-3">Download the archive file from code canyon and extract, <br />Then follow the documentation in project folder. Your business will be shine.</h4>
        <div class="my-5 w-full flex items-center flex-col md:flex-row justify-between gap-5">
            <div class="rounded-lg bg-slate-100 text-justify md:text-center flex items-center flex-col gap-5 w-full p-3">
                <Icon icon="line-md:downloading-loop" width="56" height="56" />
                <p class="text-slate-700 font-semibold">
                    Download the latest files from code canyon and setup in your server.
                </p>
            </div>
            <div class="rounded-lg bg-slate-100 text-justify md:text-center flex items-center flex-col gap-5 w-full p-3">
                <Icon icon="eos-icons:installing" width="56" height="56" />
                <p class="text-slate-700 font-semibold">
                    Follow the instruction from documentation files and install the project in right away.
                </p>
            </div>
            <div class="rounded-lg bg-slate-100 text-justify md:text-center flex items-center flex-col gap-5 w-full p-3">
                <Icon icon="heroicons:rocket-launch" width="56" height="56" />
                <p class="text-slate-700 font-semibold">
                    Launch your application and enjoy your streams.
                </p>
            </div>
        </div>
    </div>
</template>

<script setup>
import { Icon } from '@iconify/vue';
</script>
