<template>
    <div class="w-full max-w-[1060px] m-auto flex flex-col md:flex-row my-[40px] px-3 md:px-0 justify-between gap-3" data-aos="fade-up">
        <img src="../../../images/download.png" data-aos="fade-left" class="w-full" alt="instagram downloader">
        <div class="w-full" data-aos="fade-right">
            <h4 class="bg-slate-200 py-2 px-4 rounded-lg max-w-[195px] text-blue-800 font-bold">Why choose RStream</h4>
            <h1 class="font-base md:font-[700] text-slate-600 mt-3 text-[22px] md:text-[25px] ls-0">RStream is one of the best video streaming platform.</h1>
            <p class="text-justify mt-3">
                We have built this website with all modern features and technology and we have make this website most secure and functional. Now you can easily lunch your streaming platform very easily.
            </p>
            <p class="text-justify mt-3">
                All latest technology comes with this website. We use vue.js3 for the user and admin front-end side and laravel 11.x for the backend. And your all api end-point secure with authentication system.
            </p>
        </div>
    </div>
</template>
