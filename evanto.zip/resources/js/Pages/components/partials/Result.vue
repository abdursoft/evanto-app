<template>
    <div class="max-w-[1180px] m-auto">
        <h3 class="text-xl text-center">Result</h3>
    </div>
</template>
