<template>
    <head>
        <title>About Us</title>
    </head>
    <div class="flex flex-col px-2 md:px-4 items-center py-[40px]">
        <h4 class="bg-slate-200 py-2 px-4 rounded-lg max-w-[140px] text-blue-800 font-bold">{{ $t('howItWorks.tag') }}</h4>
        <h1 class="font-base md:font-[700] text-center text-slate-600 mt-3 text-[28px] md:text-[45px] ls-0">{{ $t('howItWorks.title') }}</h1>
        <h4 class="text-justify md:text-center text-slate-500 text-md md:text-lg md:font-semibold mt-2">{{ $t('howItWorks.info') }}</h4>
        <div class="mt-10 bg-slate-100 rounded-md p-2 md:p-10">
            <div class="text-justify md:text-center">Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptas esse voluptatum perferendis voluptates deleniti dicta! Commodi reiciendis, ipsum porro blanditiis quibusdam facilis consequuntur nemo quos quae nam! Deleniti nihil minima laudantium totam, veritatis optio maxime a libero blanditiis eius nostrum est iste. Quidem repudiandae reprehenderit nihil. Doloribus corporis ducimus quos voluptate quod ipsam excepturi neque. Nihil sapiente cupiditate asperiores sequi voluptatem accusamus nisi, vel alias sunt facilis molestiae nesciunt. Possimus eaque ipsa, quisquam ducimus quia nihil ipsam voluptatum obcaecati modi magnam commodi dolores expedita fuga inventore mollitia voluptates cum? Ea quisquam ut doloremque saepe totam, soluta blanditiis rerum, dolore animi hic modi nemo architecto, libero eveniet omnis magni? Quaerat maiores tempore alias nihil odio soluta, iste id consequatur esse quod a praesentium, perferendis accusamus, voluptates ullam error? Non, temporibus? Doloremque aliquam soluta esse? Vitae molestiae eaque voluptas tenetur quibusdam inventore voluptates magni sapiente sed ut recusandae nisi numquam praesentium debitis rem a natus odit rerum id, impedit perferendis! Ullam fugiat amet accusamus, ab assumenda corrupti? Voluptatem ullam placeat expedita quos sapiente odit nulla illum accusantium et quia animi corrupti ducimus, corporis maiores vitae incidunt delectus aut. Magnam officia ad sequi itaque temporibus delectus sapiente aperiam, pariatur iusto magni suscipit placeat, hic exercitationem vitae quas expedita maiores a ex aut aspernatur cumque dolor repellendus saepe? Cum sequi vero iure, nulla animi temporibus repellendus dicta placeat est quis rerum a eligendi doloribus facere soluta et suscipit, expedita corporis iusto ut. Nostrum maiores esse magni ipsam. Rem fuga natus, voluptatem quia adipisci officiis iusto? Quos, harum? Ipsam minima consequatur distinctio minus aut adipisci? Tempore dicta, quod illo perspiciatis quae libero. Unde molestias optio magnam ad illo commodi consequuntur minima voluptates reiciendis necessitatibus labore mollitia dicta aut odio quod dolor, sit impedit officiis voluptatibus quae ipsa! Expedita vero commodi sapiente nam architecto, accusantium maxime natus beatae delectus ipsa necessitatibus blanditiis voluptatem voluptatibus dolor eveniet repellendus? Odit blanditiis rem illum facere, nisi explicabo provident ratione neque suscipit porro sapiente quibusdam ullam. Vero officiis ut ad eveniet atque beatae totam quod repudiandae, natus doloremque tenetur ipsum. Amet natus blanditiis, deserunt alias ea pariatur quidem, ipsa rem fugiat dolor quibusdam excepturi et laborum expedita, nisi voluptate incidunt! Necessitatibus repudiandae voluptatem harum minus nisi quibusdam consequatur reiciendis totam eveniet, rerum non provident aliquid esse. Nisi odit aut saepe maxime illo deleniti error, et assumenda culpa nulla ab, labore officiis delectus provident, laborum facilis iste magni nihil sit quis?</div>
        </div>
    </div>
</template>

<script>
import HomeLayout from './layouts/HomeLayout.vue'
export default{
    layout: HomeLayout
}
</script>
